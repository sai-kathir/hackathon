/**
 * PathVeda // Premium UI/UX Physics & Audio Engine
 * Antigravity Canvas Particles, 3D Stage Tilt, Web Audio Synth
 */

document.addEventListener('DOMContentLoaded', () => {
    initParticleEngine();
    init3DTilt();
    initAudioEngine();
    initFormInteraction();
});

/* ==========================================================================
   1. PATHVEDA ORGANIC & GEOMETRIC PARTICLE ENGINE (Canvas)
   ========================================================================== */
function initParticleEngine() {
    const canvas = document.getElementById('particleCanvas');
    const ctx = canvas.getContext('2d');
    
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    // Shapes: emerald and orange accent spheres, rings, and floating prisms
    const shapes = ['sphere', 'ring', 'octahedron', 'tetrahedron', 'particle'];
    const particles = [];
    const particleCount = 70;

    let mouse = { x: width / 2, y: height / 2, radius: 200 };

    window.addEventListener('mousemove', (e) => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
    });

    class PathVedaParticle {
        constructor() {
            this.reset();
            this.y = Math.random() * height;
        }

        reset() {
            this.shape = shapes[Math.floor(Math.random() * shapes.length)];
            this.size = Math.random() * 20 + 4;
            this.x = Math.random() * width;
            this.y = height + this.size + Math.random() * 200;
            this.vx = (Math.random() - 0.5) * 0.4;
            this.vy = -(Math.random() * 0.5 + 0.2); // Zero-gravity upward drift
            this.angle = Math.random() * Math.PI * 2;
            this.rotSpeed = (Math.random() - 0.5) * 0.02;
            this.opacity = Math.random() * 0.5 + 0.15;
            
            // Palette: Pristine White, Forest Green (#16A34A), Warm Orange (#F97316), Silver Gray
            const rand = Math.random();
            if (rand > 0.75) {
                this.color = '22, 163, 74'; // Forest Green
            } else if (rand > 0.5) {
                this.color = '249, 115, 22'; // Orange Accent
            } else if (rand > 0.25) {
                this.color = '148, 163, 184'; // Soft Silver
            } else {
                this.color = '255, 255, 255'; // Pristine White
            }
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;
            this.angle += this.rotSpeed;

            // Antigravity mouse repulsion
            let dx = mouse.x - this.x;
            let dy = mouse.y - this.y;
            let dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < mouse.radius) {
                let force = (mouse.radius - dist) / mouse.radius;
                this.x -= (dx / dist) * force * 3.5;
                this.y -= (dy / dist) * force * 3.5;
            }

            if (this.y < -this.size - 50) {
                this.reset();
            }
            if (this.x < -this.size) this.x = width + this.size;
            if (this.x > width + this.size) this.x = -this.size;
        }

        draw() {
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.angle);

            ctx.strokeStyle = `rgba(${this.color}, ${this.opacity})`;
            ctx.fillStyle = `rgba(${this.color}, ${this.opacity * 0.25})`;
            ctx.lineWidth = 1.5;

            ctx.shadowBlur = 20;
            ctx.shadowColor = `rgba(${this.color}, ${this.opacity * 0.9})`;

            if (this.shape === 'sphere' || this.shape === 'particle') {
                ctx.beginPath();
                ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2);
                ctx.fill();
                if (this.shape === 'sphere') ctx.stroke();
            } else if (this.shape === 'ring') {
                ctx.beginPath();
                ctx.arc(0, 0, this.size, 0, Math.PI * 2);
                ctx.stroke();
                ctx.beginPath();
                ctx.arc(0, 0, this.size * 0.55, 0, Math.PI * 2);
                ctx.stroke();
            } else if (this.shape === 'octahedron') {
                ctx.beginPath();
                ctx.moveTo(0, -this.size);
                ctx.lineTo(this.size * 0.8, 0);
                ctx.lineTo(0, this.size);
                ctx.lineTo(-this.size * 0.8, 0);
                ctx.closePath();
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(0, -this.size);
                ctx.lineTo(0, this.size);
                ctx.stroke();
            } else if (this.shape === 'tetrahedron') {
                ctx.beginPath();
                ctx.moveTo(0, -this.size);
                ctx.lineTo(this.size * 0.866, this.size * 0.5);
                ctx.lineTo(-this.size * 0.866, this.size * 0.5);
                ctx.closePath();
                ctx.stroke();
            }

            ctx.restore();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new PathVedaParticle());
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);

        for (let i = 0; i < particles.length; i++) {
            particles[i].update();
            particles[i].draw();

            for (let j = i + 1; j < particles.length; j++) {
                let dx = particles[i].x - particles[j].x;
                let dy = particles[i].y - particles[j].y;
                let dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    let alpha = (1 - dist / 120) * 0.18;
                    // Entanglement lines take on a subtle forest green shimmer
                    ctx.strokeStyle = `rgba(22, 163, 74, ${alpha})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        }

        requestAnimationFrame(animate);
    }

    animate();
}

/* ==========================================================================
   2. 3D STAGE TILT & ANTIGRAVITY MONITOR
   ========================================================================== */
function init3DTilt() {
    const card = document.getElementById('tiltCard');
    const statusLabel = document.querySelector('.status-label');
    let targetX = 0, targetY = 0;
    let currentX = 0, currentY = 0;
    let isHovered = false;

    window.addEventListener('mousemove', (e) => {
        const x = e.clientX / window.innerWidth;
        const y = e.clientY / window.innerHeight;
        
        targetX = (y - 0.5) * -16;
        targetY = (x - 0.5) * 16;

        const gForce = (Math.abs(x - 0.5) + Math.abs(y - 0.5)) * 0.006;
        if (statusLabel) {
            statusLabel.textContent = `ANTIGRAVITY STAGE: STABLE ${gForce.toFixed(4)}G`;
        }
    });

    card.addEventListener('mouseenter', () => { isHovered = true; });
    card.addEventListener('mouseleave', () => { 
        isHovered = false; 
        targetX = 0;
        targetY = 0;
        if (statusLabel) statusLabel.textContent = `ANTIGRAVITY STAGE: STABLE 0.0000G`;
    });

    function updateTilt() {
        currentX += (targetX - currentX) * 0.08;
        currentY += (targetY - currentY) * 0.08;

        if (isHovered) {
            card.style.transform = `translateY(-12px) rotateX(${currentX}deg) rotateY(${currentY}deg)`;
        } else {
            card.style.transform = '';
        }

        requestAnimationFrame(updateTilt);
    }

    updateTilt();
}

/* ==========================================================================
   3. STUDIO AUDIO SYNTHESIZER
   ========================================================================== */
function initAudioEngine() {
    const soundToggle = document.getElementById('soundToggle');
    const soundIconOn = document.getElementById('soundIconOn');
    const soundIconOff = document.getElementById('soundIconOff');
    
    let audioCtx = null;
    let isMuted = true;
    let ambientGain = null;

    soundToggle.addEventListener('click', () => {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            startAmbientDrone();
        }

        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }

        isMuted = !isMuted;
        
        if (isMuted) {
            ambientGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.5);
            soundIconOn.style.display = 'none';
            soundIconOff.style.display = 'block';
        } else {
            ambientGain.gain.setTargetAtTime(0.06, audioCtx.currentTime, 1);
            soundIconOn.style.display = 'block';
            soundIconOff.style.display = 'none';
            playChime(523.25); // C5
        }
    });

    function startAmbientDrone() {
        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const filter = audioCtx.createBiquadFilter();
        ambientGain = audioCtx.createGain();

        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(130.81, audioCtx.currentTime); // C3

        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(196.00, audioCtx.currentTime); // G3

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, audioCtx.currentTime);

        ambientGain.gain.setValueAtTime(0, audioCtx.currentTime);

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(ambientGain);
        ambientGain.connect(audioCtx.destination);

        osc1.start();
        osc2.start();
    }

    window.playChime = function(freq = 880, type = 'sine', duration = 0.4) {
        if (!audioCtx || isMuted) return;

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = type;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + duration);
    };

    window.playClick = function() {
        if (!audioCtx || isMuted) return;

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1000, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(250, audioCtx.currentTime + 0.08);

        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.08);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + 0.08);
    };
}

/* ==========================================================================
   4. FORM INTERACTION & UPLINK ANIMATION
   ========================================================================== */
function initFormInteraction() {
    const inputs = document.querySelectorAll('input');
    const loginForm = document.getElementById('loginForm');
    const successPortal = document.getElementById('successPortal');
    const nameWrapper = document.getElementById('nameWrapper');
    const schoolWrapper = document.getElementById('schoolWrapper');
    const actionWrapper = document.getElementById('actionWrapper');

    inputs.forEach(input => {
        const fieldGroup = input.closest('.pill-field-group');

        input.addEventListener('focus', () => {
            if (fieldGroup) fieldGroup.classList.add('active');
            if (window.playChime) window.playChime(1046.50, 'sine', 0.2); // C6
        });

        input.addEventListener('blur', () => {
            if (fieldGroup && input.value.trim() === '') {
                fieldGroup.classList.remove('active');
            }
        });

        input.addEventListener('input', () => {
            if (fieldGroup && input.value.trim() !== '') {
                fieldGroup.classList.add('active');
            }
        });

        input.addEventListener('change', () => {
            if (fieldGroup && input.value.trim() !== '') {
                fieldGroup.classList.add('active');
            }
        });

        input.addEventListener('keydown', () => {
            if (window.playClick) window.playClick();
        });
    });

    setInterval(() => {
        inputs.forEach(input => {
            const fieldGroup = input.closest('.pill-field-group');
            if (fieldGroup) {
                if (input.value.trim() !== '') {
                    fieldGroup.classList.add('active');
                } else if (document.activeElement !== input) {
                    fieldGroup.classList.remove('active');
                }
            }
        });
    }, 50);

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();

        if (window.playChime) {
            window.playChime(659.25, 'triangle', 0.8); // E5
            setTimeout(() => window.playChime(987.77, 'sine', 1.2), 200); // B5
            setTimeout(() => window.playChime(1318.51, 'sine', 1.5), 400); // E6
        }

        nameWrapper.style.transform = 'translateY(-60px) translateZ(100px) scale(1.1)';
        nameWrapper.style.opacity = '0';
        nameWrapper.style.pointerEvents = 'none';

        schoolWrapper.style.transform = 'translateY(60px) translateZ(100px) scale(1.1)';
        schoolWrapper.style.opacity = '0';
        schoolWrapper.style.pointerEvents = 'none';

        actionWrapper.style.transform = 'translateZ(-100px) scale(0.5)';
        actionWrapper.style.opacity = '0';
        actionWrapper.style.pointerEvents = 'none';

        setTimeout(() => {
            loginForm.style.display = 'none';
            successPortal.style.display = 'block';
        }, 500);
    });
}
