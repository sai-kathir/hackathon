/**
 * PathVeda // Premium UI/UX Physics & Audio Engine
 * Antigravity Canvas Particles, 3D Stage Tilt, Web Audio Synth
 */

document.addEventListener('DOMContentLoaded', () => {
    initParticleEngine();
    init3DTilt();
    initAudioEngine();
    initFormInteraction();
});

/* ==========================================================================
   1. PATHVEDA ORGANIC & GEOMETRIC PARTICLE ENGINE (Canvas)
   ========================================================================== */
function initParticleEngine() {
    const canvas = document.getElementById('particleCanvas');
    const ctx = canvas.getContext('2d');
    
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    // Shapes: emerald and orange accent spheres, rings, and floating prisms
    const shapes = ['sphere', 'ring', 'octahedron', 'tetrahedron', 'particle'];
    const particles = [];
    const particleCount = 70;

    let mouse = { x: width / 2, y: height / 2, radius: 200 };

    window.addEventListener('mousemove', (e) => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
    });

    class PathVedaParticle {
        constructor() {
            this.reset();
            this.y = Math.random() * height;
        }

        reset() {
            this.shape = shapes[Math.floor(Math.random() * shapes.length)];
            this.size = Math.random() * 20 + 4;
            this.x = Math.random() * width;
            this.y = height + this.size + Math.random() * 200;
            this.vx = (Math.random() - 0.5) * 0.4;
            this.vy = -(Math.random() * 0.5 + 0.2); // Zero-gravity upward drift
            this.angle = Math.random() * Math.PI * 2;
            this.rotSpeed = (Math.random() - 0.5) * 0.02;
            this.opacity = Math.random() * 0.5 + 0.15;
            
            // Palette: Pristine White, Forest Green (#16A34A), Warm Orange (#F97316), Silver Gray
            const rand = Math.random();
            if (rand > 0.75) {
                this.color = '22, 163, 74'; // Forest Green
            } else if (rand > 0.5) {
                this.color = '249, 115, 22'; // Orange Accent
            } else if (rand > 0.25) {
                this.color = '148, 163, 184'; // Soft Silver
            } else {
                this.color = '255, 255, 255'; // Pristine White
            }
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;
            this.angle += this.rotSpeed;

            // Antigravity mouse repulsion
            let dx = mouse.x - this.x;
            let dy = mouse.y - this.y;
            let dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < mouse.radius) {
                let force = (mouse.radius - dist) / mouse.radius;
                this.x -= (dx / dist) * force * 3.5;
                this.y -= (dy / dist) * force * 3.5;
            }

            if (this.y < -this.size - 50) {
                this.reset();
            }
            if (this.x < -this.size) this.x = width + this.size;
            if (this.x > width + this.size) this.x = -this.size;
        }

        draw() {
            ctx.save();
            ctx.translate(this.x, this.y);
            ctx.rotate(this.angle);

            ctx.strokeStyle = `rgba(${this.color}, ${this.opacity})`;
            ctx.fillStyle = `rgba(${this.color}, ${this.opacity * 0.25})`;
            ctx.lineWidth = 1.5;

            ctx.shadowBlur = 20;
            ctx.shadowColor = `rgba(${this.color}, ${this.opacity * 0.9})`;

            if (this.shape === 'sphere' || this.shape === 'particle') {
                ctx.beginPath();
                ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2);
                ctx.fill();
                if (this.shape === 'sphere') ctx.stroke();
            } else if (this.shape === 'ring') {
                ctx.beginPath();
                ctx.arc(0, 0, this.size, 0, Math.PI * 2);
                ctx.stroke();
                ctx.beginPath();
                ctx.arc(0, 0, this.size * 0.55, 0, Math.PI * 2);
                ctx.stroke();
            } else if (this.shape === 'octahedron') {
                ctx.beginPath();
                ctx.moveTo(0, -this.size);
                ctx.lineTo(this.size * 0.8, 0);
                ctx.lineTo(0, this.size);
                ctx.lineTo(-this.size * 0.8, 0);
                ctx.closePath();
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(0, -this.size);
                ctx.lineTo(0, this.size);
                ctx.stroke();
            } else if (this.shape === 'tetrahedron') {
                ctx.beginPath();
                ctx.moveTo(0, -this.size);
                ctx.lineTo(this.size * 0.866, this.size * 0.5);
                ctx.lineTo(-this.size * 0.866, this.size * 0.5);
                ctx.closePath();
                ctx.stroke();
            }

            ctx.restore();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new PathVedaParticle());
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);

        for (let i = 0; i < particles.length; i++) {
            particles[i].update();
            particles[i].draw();

            for (let j = i + 1; j < particles.length; j++) {
                let dx = particles[i].x - particles[j].x;
                let dy = particles[i].y - particles[j].y;
                let dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    let alpha = (1 - dist / 120) * 0.18;
                    // Entanglement lines take on a subtle forest green shimmer
                    ctx.strokeStyle = `rgba(22, 163, 74, ${alpha})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        }

        requestAnimationFrame(animate);
    }

    animate();
}

/* ==========================================================================
   2. 3D STAGE TILT & ANTIGRAVITY MONITOR
   ========================================================================== */
function init3DTilt() {
    const card = document.getElementById('tiltCard');
    const statusLabel = document.querySelector('.status-label');
    let targetX = 0, targetY = 0;
    let currentX = 0, currentY = 0;
    let isHovered = false;

    window.addEventListener('mousemove', (e) => {
        const x = e.clientX / window.innerWidth;
        const y = e.clientY / window.innerHeight;
        
        targetX = (y - 0.5) * -16;
        targetY = (x - 0.5) * 16;

        const gForce = (Math.abs(x - 0.5) + Math.abs(y - 0.5)) * 0.006;
        if (statusLabel) {
            statusLabel.textContent = `ANTIGRAVITY STAGE: STABLE ${gForce.toFixed(4)}G`;
        }
    });

    card.addEventListener('mouseenter', () => { isHovered = true; });
    card.addEventListener('mouseleave', () => { 
        isHovered = false; 
        targetX = 0;
        targetY = 0;
        if (statusLabel) statusLabel.textContent = `ANTIGRAVITY STAGE: STABLE 0.0000G`;
    });

    function updateTilt() {
        currentX += (targetX - currentX) * 0.08;
        currentY += (targetY - currentY) * 0.08;

        if (isHovered) {
            card.style.transform = `translateY(-12px) rotateX(${currentX}deg) rotateY(${currentY}deg)`;
        } else {
            card.style.transform = '';
        }

        requestAnimationFrame(updateTilt);
    }

    updateTilt();
}

/* ==========================================================================
   3. STUDIO AUDIO SYNTHESIZER
   ========================================================================== */
function initAudioEngine() {
    const soundToggle = document.getElementById('soundToggle');
    const soundIconOn = document.getElementById('soundIconOn');
    const soundIconOff = document.getElementById('soundIconOff');
    
    let audioCtx = null;
    let isMuted = true;
    let ambientGain = null;

    soundToggle.addEventListener('click', () => {
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            startAmbientDrone();
        }

        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }

        isMuted = !isMuted;
        
        if (isMuted) {
            ambientGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.5);
            soundIconOn.style.display = 'none';
            soundIconOff.style.display = 'block';
        } else {
            ambientGain.gain.setTargetAtTime(0.06, audioCtx.currentTime, 1);
            soundIconOn.style.display = 'block';
            soundIconOff.style.display = 'none';
            playChime(523.25); // C5
        }
    });

    function startAmbientDrone() {
        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const filter = audioCtx.createBiquadFilter();
        ambientGain = audioCtx.createGain();

        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(130.81, audioCtx.currentTime); // C3

        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(196.00, audioCtx.currentTime); // G3

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, audioCtx.currentTime);

        ambientGain.gain.setValueAtTime(0, audioCtx.currentTime);

        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(ambientGain);
        ambientGain.connect(audioCtx.destination);

        osc1.start();
        osc2.start();
    }

    window.playChime = function(freq = 880, type = 'sine', duration = 0.4) {
        if (!audioCtx || isMuted) return;

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = type;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

        gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + duration);
    };

    window.playClick = function() {
        if (!audioCtx || isMuted) return;

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1000, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(250, audioCtx.currentTime + 0.08);

        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.08);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + 0.08);
    };
}

/* ==========================================================================
   4. FORM INTERACTION & UPLINK ANIMATION
   ========================================================================== */
function initFormInteraction() {
    const inputs = document.querySelectorAll('input');
    const loginForm = document.getElementById('loginForm');
    const successPortal = document.getElementById('successPortal');
    const nameWrapper = document.getElementById('nameWrapper');
    const schoolWrapper = document.getElementById('schoolWrapper');
    const actionWrapper = document.getElementById('actionWrapper');

    inputs.forEach(input => {
        const fieldGroup = input.closest('.pill-field-group');

        input.addEventListener('focus', () => {
            if (fieldGroup) fieldGroup.classList.add('active');
            if (window.playChime) window.playChime(1046.50, 'sine', 0.2); // C6
        });

        input.addEventListener('blur', () => {
            if (fieldGroup && input.value.trim() === '') {
                fieldGroup.classList.remove('active');
            }
        });

        input.addEventListener('input', () => {
            if (fieldGroup && input.value.trim() !== '') {
                fieldGroup.classList.add('active');
            }
        });

        input.addEventListener('change', () => {
            if (fieldGroup && input.value.trim() !== '') {
                fieldGroup.classList.add('active');
            }
        });

        input.addEventListener('keydown', () => {
            if (window.playClick) window.playClick();
        });
    });

    setInterval(() => {
        inputs.forEach(input => {
            const fieldGroup = input.closest('.pill-field-group');
            if (fieldGroup) {
                if (input.value.trim() !== '') {
                    fieldGroup.classList.add('active');
                } else if (document.activeElement !== input) {
                    fieldGroup.classList.remove('active');
                }
            }
        });
    }, 50);

    const nextBtnStep1 = document.getElementById('nextBtnStep1');
    const step1Container = document.getElementById('step1Container');
    const step2Container = document.getElementById('step2Container');
    
    const node1 = document.getElementById('node1');
    const node2 = document.getElementById('node2');
    const node3 = document.getElementById('node3');
    const line1 = document.getElementById('line1');
    const line2 = document.getElementById('line2');

    // Transition from Step 1 to Step 2
    nextBtnStep1.addEventListener('click', () => {
        // Validation check for Step 1
        const nameInput = document.getElementById('userName');
        const schoolInput = document.getElementById('userSchool');
        if (!nameInput.value || !schoolInput.value) {
            nameInput.reportValidity();
            schoolInput.reportValidity();
            return;
        }

        if (window.playChime) window.playChime(659.25, 'triangle', 0.5); // E5

        // Update Stepper
        node1.classList.remove('active');
        node1.classList.add('completed');
        line1.classList.add('active');
        node2.classList.add('active');

        // Animate out Step 1
        step1Container.style.opacity = '0';
        step1Container.style.transform = 'translateZ(-100px) scale(0.95)';
        step1Container.style.pointerEvents = 'none';

        setTimeout(() => {
            step1Container.style.display = 'none';
            step2Container.style.display = 'block';
            
            // Reflow
            void step2Container.offsetWidth;
            
            // Animate in Step 2
            step2Container.style.opacity = '1';
            step2Container.style.transform = 'translateZ(0) scale(1)';
            step2Container.style.pointerEvents = 'auto';
            
            const locationInput = document.getElementById('userLocation');
            if(locationInput) locationInput.focus();
        }, 500);
    });

    const nextBtnStep2 = document.getElementById('nextBtnStep2');
    const step3Container = document.getElementById('step3Container');

    const node4 = document.getElementById('node4');
    const line3 = document.getElementById('line3');

    // Transition from Step 2 to Step 3
    nextBtnStep2.addEventListener('click', () => {
        // Validation check for Step 2
        const locationInput = document.getElementById('userLocation');
        if (!locationInput.value) {
            locationInput.reportValidity();
            return;
        }

        if (window.playChime) window.playChime(783.99, 'triangle', 0.5); // G5

        // Update Stepper
        node2.classList.remove('active');
        node2.classList.add('completed');
        line2.classList.add('active');
        node3.classList.add('active');

        // Animate out Step 2
        step2Container.style.opacity = '0';
        step2Container.style.transform = 'translateZ(-100px) scale(0.95)';
        step2Container.style.pointerEvents = 'none';

        setTimeout(() => {
            step2Container.style.display = 'none';
            step3Container.style.display = 'block';
            
            // Reflow
            void step3Container.offsetWidth;
            
            // Animate in Step 3
            step3Container.style.opacity = '1';
            step3Container.style.transform = 'translateZ(0) scale(1)';
            step3Container.style.pointerEvents = 'auto';
            
            const marksInput = document.getElementById('userMarks');
            if(marksInput) marksInput.focus();
        }, 500);
    });

    // Final form submission (Step 3 to Success)
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Validate Select explicitly
        const interestSelect = document.getElementById('userInterest');
        if(!interestSelect.value) {
            interestSelect.reportValidity();
            return;
        }

        if (window.playChime) {
            window.playChime(659.25, 'triangle', 0.8); // E5
            setTimeout(() => window.playChime(987.77, 'sine', 1.2), 200); // B5
            setTimeout(() => window.playChime(1318.51, 'sine', 1.5), 400); // E6
        }

        // Update Stepper
        node3.classList.remove('active');
        node3.classList.add('completed');
        line3.classList.add('active');
        node4.classList.add('completed');
        node4.classList.add('active');

        // Stunning Dispersal Animation for Step 3
        step3Container.style.transform = 'translateY(-60px) translateZ(100px) scale(1.1)';
        step3Container.style.opacity = '0';
        step3Container.style.pointerEvents = 'none';

        setTimeout(() => {
            loginForm.style.display = 'none';
            document.getElementById('progressStepper').style.display = 'none';
            successPortal.style.display = 'block';

            // Transition to Dashboard Phase
            setTimeout(() => {
                const presentationCard = document.querySelector('.presentation-card');
                const dashboardStage = document.getElementById('dashboardStage');
                const displayCity = document.getElementById('displayCity');
                const userLocation = document.getElementById('userLocation').value.trim();

                // Set city dynamically
                if(userLocation) {
                    displayCity.textContent = userLocation.split(',')[0]; // Just take first part if comma separated
                }

                // Fade out login card
                presentationCard.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
                presentationCard.style.opacity = '0';
                presentationCard.style.transform = 'translateZ(-200px) scale(0.8)';
                presentationCard.style.pointerEvents = 'none';

                if (window.playChime) window.playChime(1046.50, 'sine', 1.0); // C6

                setTimeout(() => {
                    presentationCard.style.display = 'none';
                    dashboardStage.style.display = 'flex';
                    
                    // Reflow
                    void dashboardStage.offsetWidth;
                    
                    dashboardStage.style.opacity = '1';
                }, 800);
            }, 2500); // 2.5 second delay on success screen

        }, 500);
    });

    // Transition from Dashboard to Discovery Portal
    const exploreBtn = document.querySelector('.explore-btn');
    const discoveryPortal = document.getElementById('discoveryPortal');
    const discoveryCity = document.getElementById('discoveryCity');
    
    if (exploreBtn) {
        exploreBtn.addEventListener('click', () => {
            const dashboardStage = document.getElementById('dashboardStage');
            const userLocation = document.getElementById('userLocation').value.trim();
            
            // Set city dynamically
            if(userLocation) {
                discoveryCity.textContent = userLocation.split(',')[0];
            }

            if (window.playChime) window.playChime(1318.51, 'sine', 0.8); // E6

            // Fade out Dashboard
            dashboardStage.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            dashboardStage.style.opacity = '0';
            dashboardStage.style.transform = 'translateZ(-200px) scale(0.8)';
            dashboardStage.style.pointerEvents = 'none';

            setTimeout(() => {
                dashboardStage.style.display = 'none';
                renderCollegeMatches(userLocation); // Render dynamic matches
                discoveryPortal.style.display = 'flex';
                
                // Reflow
                void discoveryPortal.offsetWidth;
                
                discoveryPortal.style.opacity = '1';
            }, 800);
        });
    }

    // Scroll Down Button Logic
    const scrollDownBtn = document.getElementById('scrollDownBtn');
    if (scrollDownBtn && discoveryPortal) {
        scrollDownBtn.addEventListener('click', () => {
            discoveryPortal.scrollBy({
                top: window.innerHeight * 0.7, // Scroll down 70% of viewport height
                behavior: 'smooth'
            });
        });

        // Optional: Hide button when scrolled to bottom
        discoveryPortal.addEventListener('scroll', () => {
            const isAtBottom = discoveryPortal.scrollHeight - discoveryPortal.scrollTop <= discoveryPortal.clientHeight + 50;
            if (isAtBottom) {
                scrollDownBtn.style.opacity = '0';
                scrollDownBtn.style.pointerEvents = 'none';
            } else {
                scrollDownBtn.style.opacity = '1';
                scrollDownBtn.style.pointerEvents = 'auto';
            }
        });
    }

    // Go Home Button Logic
    const goHomeBtn = document.getElementById('goHomeBtn');
    if (goHomeBtn) {
        goHomeBtn.addEventListener('click', () => {
            if (window.playChime) window.playChime(523.25, 'sine', 0.8); // C5
            
            // Fade out the entire discovery portal faster
            discoveryPortal.style.transition = 'opacity 0.3s ease';
            discoveryPortal.style.opacity = '0';

            setTimeout(() => {
                discoveryPortal.style.display = 'none';
                
                // 1. Reset forms
                const loginForm = document.getElementById('loginForm');
                if(loginForm) loginForm.reset();

                // 2. Reset Step 1
                const step1Container = document.getElementById('step1Container');
                if(step1Container) {
                    step1Container.style.display = 'block';
                    step1Container.style.opacity = '1';
                    step1Container.style.transform = 'translateZ(0) scale(1)';
                    step1Container.style.pointerEvents = 'auto';
                    step1Container.classList.add('active-step');
                }

                // 3. Reset Step 2 & 3
                ['step2Container', 'step3Container'].forEach(id => {
                    const el = document.getElementById(id);
                    if(el) {
                        el.style.display = 'none';
                        el.style.opacity = '0';
                        el.style.transform = 'translateZ(50px) scale(0.95)';
                        el.classList.remove('active-step');
                    }
                });

                // 4. Reset Stepper Nodes
                const n1 = document.getElementById('node1');
                if(n1) { n1.className = 'step-node active'; }
                [2, 3, 4].forEach(num => {
                    const node = document.getElementById('node' + num);
                    if(node) node.className = 'step-node';
                });
                [1, 2, 3].forEach(num => {
                    const line = document.getElementById('line' + num);
                    if(line) line.className = 'step-line';
                });

                // 5. Restore presentation card & stepper
                const presentationCard = document.querySelector('.presentation-card');
                const progressStepper = document.getElementById('progressStepper');
                const successPortal = document.getElementById('successPortal');

                if(successPortal) successPortal.style.display = 'none';
                if(loginForm) loginForm.style.display = 'block';
                if(progressStepper) progressStepper.style.display = 'flex';
                
                if(presentationCard) {
                    presentationCard.style.display = 'block';
                    presentationCard.style.opacity = '1';
                    presentationCard.style.transform = 'translateZ(0) scale(1)';
                    presentationCard.style.pointerEvents = 'auto';
                }

                // 6. Reset labels (trigger inputs to blur)
                document.querySelectorAll('.pill-field-group input, .pill-field-group select').forEach(el => {
                    const label = el.nextElementSibling;
                    if (label && label.classList.contains('pill-floating-label')) {
                        label.style.transform = 'translateY(0) scale(1)';
                        label.style.color = 'var(--text-faint)';
                    }
                });

            }, 300);
        });
    }
}

/* ==========================================================================
   GLOBAL DATABASE & MATCHING ENGINE
   ========================================================================== */
const globalCollegeDatabase = [
  {"name": "IIT (ISM) Dhanbad", "city": "Dhanbad", "state": "Jharkhand", "type": "IIT", "fees_ug_inr": 225000.0, "placement_avg_lpa": 12.0, "rating": 8.4, "nirf_rank": 15},
  {"name": "IIT Bhilai", "city": "Raipur", "state": "Chhattisgarh", "type": "IIT", "fees_ug_inr": 220000.0, "placement_avg_lpa": 12.0, "rating": 7.5, "nirf_rank": 95},
  {"name": "IIT BHU Varanasi", "city": "Varanasi", "state": "Uttar Pradesh", "type": "IIT", "fees_ug_inr": 220000.0, "placement_avg_lpa": 20.0, "rating": 8.6, "nirf_rank": 10},
  {"name": "IIT Bhubaneswar", "city": "Bhubaneswar", "state": "Odisha", "type": "IIT", "fees_ug_inr": 224000.0, "placement_avg_lpa": 14.0, "rating": 7.9, "nirf_rank": 39},
  {"name": "IIT Bombay", "city": "Mumbai", "state": "Maharashtra", "type": "IIT", "fees_ug_inr": 228000.0, "placement_avg_lpa": 19.61, "rating": 8.9, "nirf_rank": 3},
  {"name": "IIT Delhi", "city": "New Delhi", "state": "Delhi", "type": "IIT", "fees_ug_inr": 227750.0, "placement_avg_lpa": 19.08, "rating": 9.4, "nirf_rank": 2},
  {"name": "IIT Dharwad", "city": "Dharwad", "state": "Karnataka", "type": "IIT", "fees_ug_inr": 218000.0, "placement_avg_lpa": 11.62, "rating": 7.6, "nirf_rank": 77},
  {"name": "IIT Gandhinagar", "city": "Gandhinagar", "state": "Gujarat", "type": "IIT", "fees_ug_inr": 229426.0, "placement_avg_lpa": 14.0, "rating": 8.2, "nirf_rank": 25},
  {"name": "IIT Goa", "city": "Ponda", "state": "Goa", "type": "IIT", "fees_ug_inr": 220000.0, "placement_avg_lpa": 13.0, "rating": 7.7, "nirf_rank": 90},
  {"name": "IIT Guwahati", "city": "Guwahati", "state": "Assam", "type": "IIT", "fees_ug_inr": 224500.0, "placement_avg_lpa": 21.6, "rating": 8.8, "nirf_rank": 8},
  {"name": "IIT Hyderabad", "city": "Hyderabad", "state": "Telangana", "type": "IIT", "fees_ug_inr": 230000.0, "placement_avg_lpa": 21.0, "rating": 9.0, "nirf_rank": 14},
  {"name": "VIT University", "city": "Chennai", "state": "Tamil Nadu", "type": "Private", "fees_ug_inr": 350000.0, "placement_avg_lpa": 9.9, "rating": 6.5, "nirf_rank": null},
  {"name": "VIT Vellore", "city": "Vellore", "state": "Tamil Nadu", "type": "Private", "fees_ug_inr": 198000.0, "placement_avg_lpa": 7.5, "rating": 8.2, "nirf_rank": 14},
  {"name": "Vivekananda Global University", "city": "Jaipur", "state": "Rajasthan", "type": "Private", "fees_ug_inr": 185000.0, "placement_avg_lpa": 46.0, "rating": 8.5, "nirf_rank": null},
  {"name": "VJTI Mumbai", "city": "Mumbai", "state": "Maharashtra", "type": "Government", "fees_ug_inr": 110000.0, "placement_avg_lpa": 10.0, "rating": 8.2, "nirf_rank": null},
  {"name": "Woxsen University", "city": "Hyderabad", "state": "Telangana", "type": "Private", "fees_ug_inr": 900000.0, "placement_avg_lpa": 7.5, "rating": 6.5, "nirf_rank": null}
];

function renderCollegeMatches(userLocationInput) {
    const container = document.getElementById('dynamicCollegeContainer');
    if(!container) return;

    // 1. Context Capture & Parsing
    const locationParts = userLocationInput.split(',').map(s => s.trim().toLowerCase());
    const userCity = locationParts[0] || '';
    const userState = locationParts[1] || '';

    // 2. Dynamic Matching Engine
    let scoredColleges = globalCollegeDatabase.map(college => {
        let score = 0;
        let isCityMatch = false;
        let isStateMatch = false;
        
        const collegeCity = college.city.toLowerCase();
        const collegeState = college.state.toLowerCase();

        if (userCity && collegeCity === userCity) { score += 1000; isCityMatch = true; }
        if (userState && collegeState === userState) { score += 500; isStateMatch = true; }
        else if (userCity && collegeState === userCity) { score += 500; isStateMatch = true; } // fallback if only state entered

        // Academic prestige scoring
        if (college.nirf_rank) score += (200 - college.nirf_rank); // Lower NIRF is better
        score += (college.rating * 10);

        // Simulated Match Percentage
        let matchPercent = 60 + Math.floor(Math.random() * 15); 
        if(isCityMatch) matchPercent = 95 + Math.floor(Math.random() * 4);
        else if (isStateMatch) matchPercent = 85 + Math.floor(Math.random() * 9);

        return { ...college, matchScore: score, matchPercent: matchPercent };
    });

    // Sort by descending score
    scoredColleges.sort((a, b) => b.matchScore - a.matchScore);

    const bestFit = scoredColleges[0];
    const topMatches = scoredColleges.slice(1, 5);

    // 3. Render Best Fit Hero Presentation
    let htmlContent = `
        <div class="hero-match-card">
            <div class="hero-match-info">
                <div class="hero-match-badge">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                    </svg>
                    Absolute Best Fit
                </div>
                <h2>${bestFit.name}</h2>
                <p>${bestFit.city}, ${bestFit.state} &bull; ${bestFit.type} Institution</p>
                <div class="hero-match-stats">
                    <div class="hero-stat-item">
                        <span class="hero-stat-label">Avg Placement</span>
                        <span class="hero-stat-value">${bestFit.placement_avg_lpa} LPA</span>
                    </div>
                    <div class="hero-stat-item">
                        <span class="hero-stat-label">Platform Rating</span>
                        <span class="hero-stat-value">${bestFit.rating} / 10</span>
                    </div>
                </div>
            </div>
            <a href="#" class="hero-match-action">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    `;

    // 4. Render Individual Layout Blocks (Staggered Offsets)
    topMatches.forEach((college, index) => {
        const rankNum = index + 2; // Since Hero is #1
        const rankColor = rankNum === 2 ? 'green-text' : (rankNum === 3 ? 'orange-text' : 'text-muted');
        const matchColor = college.matchPercent >= 90 ? 'green-text' : (college.matchPercent >= 80 ? 'orange-text' : 'text-muted');
        const stgClass = `float-stagger-${index + 1}`;

        htmlContent += `
            <div class="college-card ${stgClass}">
                <div class="card-ambient-shadow-sm"></div>
                <div class="college-card-glass">
                    <div class="college-rank ${rankColor}">#${rankNum}</div>
                    <div class="college-info">
                        <h3>${college.name}</h3>
                        <p>${college.city}, ${college.state} &bull; ${college.nirf_rank ? 'NIRF Rank ' + college.nirf_rank : college.type}</p>
                    </div>
                    <div class="college-match ${matchColor}">${college.matchPercent}% Match</div>
                </div>
            </div>
        `;
    });

    container.innerHTML = htmlContent;
}
