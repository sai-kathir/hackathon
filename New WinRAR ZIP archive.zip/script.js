document.addEventListener('DOMContentLoaded', () => {
    const entryScreen = document.getElementById('entryScreen');
    const signUpForm = document.getElementById('signUpForm');
    const home = document.getElementById('home');
    const navbar = document.querySelector('.navbar');

    const portal = document.getElementById('portal');
    const portalContent = document.getElementById('portal-content');

    const openChatBtn = document.getElementById('openChat');
    const closeChatBtn = document.getElementById('closeChat');
    const chatWidget = document.getElementById('vedaChat');
    const sendMsgBtn = document.getElementById('sendMsg');
    const chatInput = document.getElementById('chatInput');
    const chatBody = document.getElementById('chatBody');

    // 1. SUPABASE CONFIGURATION
    const SUPABASE_URL = "https://yasgiyafybxtdgjkikxx.supabase.co";
    const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlhc2dpeWFmeWJ4dGRnamtpa3h4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg5OTA5MjAsImV4cCI6MjA5NDU2NjkyMH0.n_m6BDziUCQBG6LYQoU5yiJopNIDJMrKspxTR6lkZOM";
    const _supabase = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    // 2. OPENROUTER AI CONFIGURATION
    const OPENROUTER_API_KEY = "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";
    const MODEL_ID = "google/gemini-2.0-flash-lite-preview-02-05:free";

    async function getVedaAIResponse(messages) {
        try {
            const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://veda-ai.com",
                    "X-Title": "Veda AI"
                },
                body: JSON.stringify({
                    "model": MODEL_ID,
                    "messages": messages,
                    "temperature": 0.7
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                return `Veda Error: ${errorData.error?.message || "Connection failed."}`;
            }

            const data = await response.json();
            return data.choices[0].message.content;
        } catch (error) {
            return "Veda Intelligence is currently offline.";
        }
    }

    // 3. AUTH FLOW (LITERAL SUPABASE CONNECTION)
    if (signUpForm) {
        signUpForm.onsubmit = async (e) => {
            e.preventDefault();
            const email = document.getElementById('userEmail').value;
            const btn = signUpForm.querySelector('button');
            btn.textContent = "Connecting to Supabase...";
            btn.disabled = true;

            // Step 1: Sign in with OTP (Simplest for this UI)
            const { error } = await _supabase.auth.signInWithOtp({ email });

            if (error) {
                console.warn("Auth Info:", error.message);
                // For hackathon/demo purposes, we allow immediate entry if Supabase config is pending
                // In production, you would wait for OTP verification
            }

            entryScreen.classList.add('hidden');
            home.classList.remove('hidden');
            navbar.classList.remove('hidden');
        };
    }

    // 4. PORTAL MANAGEMENT
    window.openPortal = (type) => {
        home.classList.add('hidden');
        portal.classList.remove('hidden');
        renderPortal(type);
        window.scrollTo(0, 0);
    };

    window.goHome = () => {
        home.classList.remove('hidden');
        portal.classList.add('hidden');
    };

    function renderPortal(type) {
        if (type === 'student') {
            portalContent.innerHTML = `
                <h2>Student Strategy Center</h2>
                <div class="grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px; margin-top: 30px;">
                    <div class="card" style="background:white; padding:30px; border-radius:20px;">
                        <h3>Veda Metric Input</h3>
                        <div class="form-group"><label>12th Aggregate %</label><input type="number" id="marks" placeholder="e.g. 96"></div>
                        <div class="form-group"><label>Your Locality/City</label><input type="text" id="locality" placeholder="e.g. Mumbai, Delhi"></div>
                        <div class="form-group"><label>Career Interest</label><input type="text" id="interests" placeholder="e.g. Robotics Engineer"></div>
                        <button class="btn btn-primary btn-block" onclick="generateVedaAdvice()">Run Precision Analysis</button>
                    </div>
                    <div id="adviceContainer" class="card" style="background:white; padding:30px; border-radius:20px;">
                        <h3>Veda Precision Output</h3>
                        <p>Waiting for metrics...</p>
                    </div>
                </div>
            `;
        } else {
            portalContent.innerHTML = `<h2>Portal Active</h2><p>Accessing AI-powered institutional data.</p>`;
        }
    }

    // 5. LIVE DATA PERSISTENCE (Saves results to Supabase)
    window.generateVedaAdvice = async () => {
        const marksInput = document.getElementById('marks');
        const localityInput = document.getElementById('locality');
        const interestsInput = document.getElementById('interests');

        const marks = marksInput.value;
        const locality = localityInput.value;
        const interests = interestsInput.value;
        const container = document.getElementById('adviceContainer');

        if (!marks || !interests || !locality) {
            alert("Veda requires complete metrics for 100% accuracy mapping.");
            return;
        }

        container.innerHTML = `
            <div class="training-simulation">
                <h3>Veda Dataset Training...</h3>
                <p style="font-size: 0.8rem; color: var(--gray);">[LOG]: Syncing with Live Supabase Backend...</p>
                <div class="progress-bar" style="height: 10px; background: #eee; border-radius: 10px; margin-top: 10px; overflow: hidden;">
                    <div class="progress-fill" style="width: 75%; height: 100%; background: var(--primary); transition: width 2s ease;"></div>
                </div>
            </div>
        `;

        const prompt = `You are Veda AI. Student Metrics: ${marks}%, Locality: ${locality}, Interests: ${interests}.
        Rules: 
        1. 2 high-quality localized college suggestions.
        2. 1 global elite target.
        3. Professional Veda Opinion for each.
        Format in HTML structure for a card. Ensure logo.png is visible and 100px.`;

        const aiResponse = await getVedaAIResponse([{ role: "user", content: prompt }]);

        // SAVE TO SUPABASE (Requirement 13)
        const { data: { user } } = await _supabase.auth.getUser();
        if (user) {
            await _supabase.from('career_roadmaps').insert({
                student_id: user.id,
                roadmap_title: `${interests} Roadmap`,
                veda_opinion: aiResponse
            });
        }

        container.innerHTML = `
            <div class="advice-header" style="text-align:center; margin-bottom: 30px;">
                <img src="logo.png" style="width: 100px; height: auto; margin-bottom: 20px;">
                <div style="color: #10b981; font-weight: 800; font-size: 1rem;">✓ VEDA AI: LIVE BACKEND SYNCED</div>
            </div>
            <div class="ai-content-output">
                ${aiResponse}
            </div>
        `;
    };

    // 6. Chat Widget with Supabase Context
    if (openChatBtn) {
        openChatBtn.onclick = () => { chatWidget.style.display = 'flex'; openChatBtn.style.display = 'none'; };
    }
    if (closeChatBtn) {
        closeChatBtn.onclick = () => { chatWidget.style.display = 'none'; openChatBtn.style.display = 'block'; };
    }

    const addChatMessage = (text, sender) => {
        const div = document.createElement('div');
        div.className = `msg ${sender}`;
        div.textContent = text;
        chatBody.appendChild(div);
        chatBody.scrollTop = chatBody.scrollHeight;
    };

    if (sendMsgBtn) {
        sendMsgBtn.onclick = async () => {
            const text = chatInput.value.trim();
            if (!text) return;
            addChatMessage(text, 'user');
            chatInput.value = '';

            const thinkingId = Date.now();
            const thinkingDiv = document.createElement('div');
            thinkingDiv.className = 'msg bot';
            thinkingDiv.id = `thinking-${thinkingId}`;
            thinkingDiv.textContent = "Veda is thinking...";
            chatBody.appendChild(thinkingDiv);

            const aiResponse = await getVedaAIResponse([
                { role: "system", content: "You are Veda AI, connected to a live Supabase backend." },
                { role: "user", content: text }
            ]);

            const thinkingMsg = document.getElementById(`thinking-${thinkingId}`);
            if (thinkingMsg) thinkingMsg.remove();

            addChatMessage(aiResponse, 'bot');
        };
    }

    if (chatInput) {
        chatInput.onkeypress = (e) => { if (e.key === 'Enter') sendMsgBtn.click(); };
    }
});
